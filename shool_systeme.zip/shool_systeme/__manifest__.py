{
    'name': 'School System',
    'version': '16.0',
    'summary': '',
    'author': 'Nyab',
    'category': '',
    'depends': [],
    'data': [

        'views/menu.xml',
        'security/ir.model.access.csv',

        'views/teachers.xml',
        'views/student.xml',
        'views/classe.xml',
        'views/matiere.xml',
        'views/bulletin.xml',
        'report/report_bulletin.xml',



    ],
    'installable': True,
    'application': True,
}
