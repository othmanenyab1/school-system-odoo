from odoo import models, fields, api

class BulletinLigne(models.Model):
    _name = 'bulletin.ligne'
    _description = 'Bulletin ligne'

    matiere_id = fields.Many2one(comodel_name="matiere", string="Matiére")
    note = fields.Float(sting="Note",required=True)
    bulletin_id = fields.Many2one(comodel_name="bulletin", string="Bulletin")
    coefficient = fields.Float(string="Coefficient")


