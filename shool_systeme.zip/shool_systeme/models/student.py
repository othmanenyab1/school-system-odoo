import datetime
from odoo import models, fields, api

class Student(models.Model):
    _name = 'student'
    _description = 'Student'
    _rec_name = 'nom'

    nom = fields.Char(string='Nom', required=True)
    prenom = fields.Char(string='Prénom', required=True)
    teacher_id = fields.Many2one(comodel_name="teacher", string="Teacher")
    age = fields.Integer(string='Age',required=True)
    date_of_birth = fields.Date(string='Date de naissance', required=True)

    @api.model
    def action_student_menu(self):
        return {
            'name': 'Students',
            'type': 'ir.actions.act_window',
            'res_model': 'student',
            'view_mode': 'tree',
            'view_id': self.env.ref('school_systeme.view_student_tree').id,
        }

